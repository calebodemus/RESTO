<?php
// views.class.php
class Views
{
	public function displayHeader()
	{

	}
	public function displayContent()
	{

	}
	public function display()
	{

	}
}


// models/carte.class.php
class Carte
{
	private $id;
	private $id_categorie;
	private $categorie;
	private $libelle;
	private $descriptif;
	private $prix_libraison;
	private $prix_emporter;
	private $url;

	public function display()
	{
		
	}
	public function getShortDescriptif()
	{
		return substr($this->descriptif, 0, 10).'...';
	}
	public function displayInTab()
	{
		require('test.html');
	}
	public function displayFull()
	{

	}
	public function displayShort()
	{

	}
	public function getCategorie()
	{
		if ($this->categorie)
			return $this->categorie;
	}
}




$mysqli = mysqli_connect("localhost","root","troiswa","bugs");
$res = mysqli_query($mysqli, "SELECT * FROM carte");


echo "<table border=1>";
while ($carte = mysqli_fetch_object($res, 'Carte'))
{
	//echo $carte->getShortDescriptif().'<br />';
	$carte->displayInTab();
}
echo "</table>";
?>